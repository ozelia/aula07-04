var valorDaCompra = 90.00;
var valorVista = valorDaCompra-(valorDaCompra*0.1);
var valorPrazo = valorDaCompra/3;

console.log('O valor a vista é: '+valorVista);
console.log('O valor a prazo em 3x é: '+valorPrazo);