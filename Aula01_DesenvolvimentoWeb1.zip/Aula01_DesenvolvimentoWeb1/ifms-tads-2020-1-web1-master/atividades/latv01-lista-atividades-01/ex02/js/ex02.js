var valorTotal = 100;
var numeroDeClientes = 4;
var valorPorCliente = valorTotal/numeroDeClientes;
console.log('Valor por Cliente: '+valorPorCliente);