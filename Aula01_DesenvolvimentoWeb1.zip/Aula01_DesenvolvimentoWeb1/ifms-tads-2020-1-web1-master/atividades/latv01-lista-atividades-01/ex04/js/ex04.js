
var nota1 = 7.0;
var nota2 = 8.0;
var media = (nota1+nota2)/2;
console.log('A média é: '+media);